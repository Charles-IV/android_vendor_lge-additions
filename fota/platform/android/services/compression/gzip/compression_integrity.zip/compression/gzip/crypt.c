/* crypt.c (dummy version) -- do not perform encryption
 * Hardly worth copyrighting :-)
 */
#ifdef RCSID
static char rcsid[] = "$Id: crypt.c,v 0.7 2006/11/20 08:40:33 eggert Exp $";
#endif
typedef int dummy;
