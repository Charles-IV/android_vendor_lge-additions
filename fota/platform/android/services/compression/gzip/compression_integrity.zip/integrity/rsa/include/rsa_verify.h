
/**
 * Filename :$File:$
 *
 * Revision :$Revision:$
 *
 * Copyright (c) LG Electronics Inc. YYYY
 *
 * Description : Example
 *
 * Date                Author                        Change
 * ----------       ----------------    ------------------------------------------
 *
 */

//----------------------------------------------------------------------------------------------
// Golbal Function
//----------------------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

extern ua_u32        RSA_CheckSign(ua_s8 *obj, ua_u32 obj_len, ua_u32 *SIG_LENGTH, sFileSys *spKey, ua_s32 (*Seek)(ua_u32), ua_s32 (*Read)(ua_u8 *, ua_u32));
extern ua_u32        RSA2048_CheckSign(ua_s8 *obj, ua_u32 obj_len, ua_u32 *SIG_LENGTH, sFileSys *spKey, ua_s32 (*Seek)(ua_u32), ua_s32 (*Read)(ua_u8 *, ua_u32));
#ifdef __cplusplus
}
#endif  /* __cplusplus */
