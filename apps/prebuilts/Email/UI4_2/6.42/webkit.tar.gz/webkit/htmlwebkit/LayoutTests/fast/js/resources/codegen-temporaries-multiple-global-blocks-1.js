function assign1()
{
    v1 = 0;
    return 1;
}

function assign2()
{
    v2 = { a: 0 };
    return 2;
}

function assign3()
{
    v3 = { a: 0 };
    return 1;
}

function assign4()
{
    v4 = { a: 0 };
    return "a";
}

function assign5()
{
    v5 = { a: 0 };
    return "a";
}

function assign6()
{
    v6 = { a: 0 };
    return 2;
}

function assign7()
{
    v7 = { a: 0 };
    return "a";
}

function assign8()
{
    v8 = { a: 0 };
    return 1;
}
